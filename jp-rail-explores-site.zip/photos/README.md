# Your travel photos go here

Upload your original JPG, PNG, or WebP photos into this folder. Then update the matching `image` path in `../trips.js`, for example:

```js
image: "photos/yellowstone-bison.jpg",
```

Keep filenames simple (letters, numbers, and hyphens). The files provided in the previous conversation were screenshots of GitHub, not the travel photos, so this folder is ready for your selected images.
